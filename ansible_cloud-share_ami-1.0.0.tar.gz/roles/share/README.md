# ansible_cloud.share_ami role

This role will share AMIs with specific accounts.  Please see root README.md for additional info!
